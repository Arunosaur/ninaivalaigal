# Pragna — Layman Slides
## What it is
- Higher reasoning/insight engine.
- Looks across memories to find patterns.
## Value
- Turns logs into lessons.
- Suggests next steps.
## Analogy
- Strategist who studies trends and advises.
## Bigger Picture
- Works with SmritiOS and Ninaivalaigal to generate foresight.